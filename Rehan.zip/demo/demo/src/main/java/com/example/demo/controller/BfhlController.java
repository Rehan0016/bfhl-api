package com.example.demo.controller;

import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController
public class BfhlController {

    private final String EMAIL = "rehan2191.be23@chitkara.edu.in";

    // ---------------- HEALTH ----------------
    @GetMapping("/health")
    public Map<String,Object> health(){
        return Map.of(
                "is_success", true,
                "official_email", EMAIL
        );
    }

    // ---------------- MAIN API ----------------
    @PostMapping("/bfhl")
    public Map<String,Object> bfhl(@RequestBody Map<String,Object> body){

        if(body.size()!=1){
            return Map.of(
                    "is_success", false,
                    "official_email", EMAIL,
                    "error","Send exactly one key"
            );
        }

        String key = body.keySet().iterator().next();
        Object value = body.get(key);
        Object result = null;

        switch(key){

            case "fibonacci":
                result = fibonacci((Integer)value);
                break;

            case "prime":
                result = filterPrimes((List<Integer>) value);
                break;

            case "lcm":
                result = lcm((List<Integer>) value);
                break;

            case "hcf":
                result = hcf((List<Integer>) value);
                break;

            case "AI":
                result = "Mumbai"; // simple static answer
                break;

            default:
                return Map.of(
                        "is_success", false,
                        "official_email", EMAIL,
                        "error","Invalid key"
                );
        }

        return Map.of(
                "is_success", true,
                "official_email", EMAIL,
                "data", result
        );
    }

    // ---------------- LOGIC ----------------

    private List<Integer> fibonacci(int n){
        List<Integer> list = new ArrayList<>();
        int a=0,b=1;

        for(int i=0;i<n;i++){
            list.add(a);
            int c=a+b;
            a=b;
            b=c;
        }
        return list;
    }

    private boolean isPrime(int n){
        if(n<2) return false;
        for(int i=2;i*i<=n;i++)
            if(n%i==0) return false;
        return true;
    }

    private List<Integer> filterPrimes(List<Integer> nums){
        List<Integer> res = new ArrayList<>();
        for(int x: nums)
            if(isPrime(x)) res.add(x);
        return res;
    }

    private int gcd(int a,int b){
        return b==0 ? a : gcd(b,a%b);
    }

    private int lcm(List<Integer> nums){
        int res = nums.get(0);
        for(int i=1;i<nums.size();i++)
            res = res * nums.get(i) / gcd(res,nums.get(i));
        return res;
    }

    private int hcf(List<Integer> nums){
        int res = nums.get(0);
        for(int i=1;i<nums.size();i++)
            res = gcd(res, nums.get(i));
        return res;
    }
}